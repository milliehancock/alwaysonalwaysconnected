Recreated from the book code after the author's web site went down
and I could not get the code.

NOT YET TESTED.