This is the target for the TestTargetTest project used in the recipe
entitled "Creating and Using a Test Project". The names and directory
structure have been changed to follow the Eclipse project directory
structure.
