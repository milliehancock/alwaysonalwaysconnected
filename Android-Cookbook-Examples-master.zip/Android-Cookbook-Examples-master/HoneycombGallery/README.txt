This is the Honeycomb Photo Gallery example.

WE KNOW THE CODE IS INCOMPLETE. Please fix it and send a patch
against the repo, or clone it and send a pull request. Thanks.
