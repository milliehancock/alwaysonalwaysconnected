This is a PARTIAL reconstruction of the Epoch Calendar example by Wagied Davids.

It starts up but has no hope of working yet. We remain optimistic Mr. Davids will come through
with the missing pieces soon.
