To run this demo, install a TTF font in this folder, named fontdemo.ttf.
