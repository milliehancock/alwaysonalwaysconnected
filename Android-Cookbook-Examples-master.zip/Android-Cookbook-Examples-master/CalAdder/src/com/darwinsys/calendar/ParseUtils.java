package com.darwinsys.calendar;

import java.util.Date;

public class ParseUtils {

	/** parse input like:
	 * Monday, January 23, 2012 10:30 AM-12:30 PM. (UTC-05.00) Eastern Time (US & Canada)
	 * @param input Date as above
	 * @return
	 */
	public static Date[] parse(String input) {
		// TODO convert standard date format, including time range
		return new Date[] { new Date() };
	}

}
